#include <stdio.h>
#include <stdlib.h>
#include <mysql.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include "sim_trace.h"

#define DEFAULT_START_TIMESTAMP 1420066800
static const char DEFAULT_START[] = "2015-01-01 00:00:00";


/*static*/ void finish_with_error(MYSQL *con)
{
  fprintf(stderr, "%s\n", mysql_error(con));
  mysql_close(con);
  exit(1);        
}

/*static*/ void print_usage(){
	printf("\nUsage:\n");
	printf("Mode 1: mysql_trace_builder (default start = 2015-01-01 00:00:00 END = now)\n");
	printf("Mode 2: mysql_trace_builder START (format: yyyy-MM-DD hh:mm:ss). END = now\n");
	printf("Mode 3: mysql_trace_builder START (format: yyyy-MM-DD hh:mm:ss) END (format: yyyy-MM-DD hh:mm:ss)\n\n");
}


int
main(int argc, char **argv) {

	MYSQL *conn;
	MYSQL_RES *res;
	MYSQL_ROW row;
	char *server = "yourserver.yourdomain";
	char *user = "your_user";
	char *password = "your_passwd";
	char *database = "slurm_acct_db";
	conn = mysql_init(NULL);
	int i;
	job_trace_t new_trace;
	int trace_file;
	int written;
	char start[20];
	char end[20];
	long int start_timestamp;
	long int stop_timestamp;
	char year[4], month[2], day[2], hours[2], minutes[2], seconds[2];
	time_t now;
	struct tm  ts;
	char time_now[20];
	char query[300];	

	
	if ( argc == 1){
	
		strcpy(start, "2015-01-01 00:00:00");
		time(&now);
		ts = *localtime(&now);
		strftime(end, sizeof(end), "%Y-%m-%d %H:%M:%S", &ts);
		
	}
	else if ( argc == 3){
	
		if ( sscanf(argv[1], "%4s-%2s-%2s", year, month, day) != 3 ){
			print_usage();
	                return -1;
		}
		if ( sscanf(argv[2], "%2s:%2s:%2s", hours, minutes, seconds) != 3 ){
                        print_usage();
                        return -1;
                }		
	
		snprintf(start, sizeof(start), "%s-%s-%s %s:%s:%s", year,month,day,hours,minutes,seconds);

		time(&now); 
                ts = *localtime(&now);
                strftime(end, sizeof(end), "%Y-%m-%d %H:%M:%S", &ts);

	}
	else if (argc == 5){
	
		 if ( sscanf(argv[1], "%4s-%2s-%2s", year, month, day) != 3 ){
                        print_usage(); 
                        return -1;
                 }
                 if ( sscanf(argv[2], "%2s:%2s:%2s", hours, minutes, seconds) != 3 ){
                        print_usage(); 
                        return -1;
                 }

		 snprintf(start, sizeof(start), "%s-%s-%s %s:%s:%s", year,month,day,hours,minutes,seconds);	

 		 if ( sscanf(argv[3], "%4s-%2s-%2s", year, month, day) != 3 ){
                        print_usage(); 
                        return -1;
                 }
                 if ( sscanf(argv[4], "%2s:%2s:%2s", hours, minutes, seconds) != 3 ){
			 print_usage();
                         return -1;
                 }
		 
		 snprintf(end, sizeof(end), "%s-%s-%s %s:%s:%s", year,month,day,hours,minutes,seconds);


	}
	else{
		print_usage();
                return -1;
	}

	printf("START %s\n",start);
        printf("END   %s\n",end);

	/*MYSQL QUERY GENERATION*/
	snprintf(query, sizeof(query), "SELECT id_job, account, cpus_req, id_user, partition, time_submit, timelimit, (time_end-time_start) as duration from dora_job_table where FROM_UNIXTIME(time_submit) BETWEEN '%s' AND '%s' AND time_end>0 ", start, end);
	/*printf("\nMYSQL QUERY: %s\n",query);*/

	/* Connect to database */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0)) {
		finish_with_error(conn);
	}

	/* send SQL query */
	if (mysql_query(conn, query)) {
		finish_with_error(conn);
	}
	res = mysql_store_result(conn);

	if (res == NULL) 
  	{
		finish_with_error(conn);
	}

	int num_fields = mysql_num_fields(res);

	//open trace file:
	if((trace_file = open("simple.trace", O_CREAT | O_RDWR, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)) < 0){
		printf("Error opening file simple.trace\n");
		return -1;
        }

	int n = 1000;
  
	while (row = mysql_fetch_row(res)){ 
		
		new_trace.job_id = atoi(row[0]);
		new_trace.submit = strtoul(row[5], NULL, 0);
		sprintf(new_trace.username, "%s", "beninim");
		sprintf(new_trace.partition, "%s", "normal");
		sprintf(new_trace.account, "%s", "csstaff");
		new_trace.duration = 10;
		new_trace.wclimit = 12;		
		new_trace.cpus_per_task = 1;
                new_trace.tasks_per_node = 1;
		new_trace.tasks = 1;
		
		/*new_trace.submit = strtoul(row[5], NULL, 0);
		new_trace.duration = atoi(row[7]);  in seconds
		new_trace.wclimit = atoi(row[6]);   in minutes*/		
		
		new_trace.cpus_per_task = 1;
                new_trace.tasks_per_node = 4;
		new_trace.tasks = atoi(row[2]);		

		sprintf(new_trace.reservation, "%s", "");
		sprintf(new_trace.qosname, "%s", "");

		written = write(trace_file, &new_trace, sizeof(new_trace));
		if(written != sizeof(new_trace)){
			printf("Error writing to file: %d of %ld\n", written, sizeof(new_trace));
			return -1;
                 }	

	}

	/* close connection */
	mysql_free_result(res);
	mysql_close(conn);

	return 0;
}
