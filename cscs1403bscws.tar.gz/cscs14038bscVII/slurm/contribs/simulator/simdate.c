/*
 * simdate: will print the time of the simulator (when using the simulator).
 * Compile: $ gcc -g -o simdate simdate.c -I ./slurm -lpthread -lrt
 */

#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <pthread.h>

#define SLURM_SIM_SHM "/tester_slurm_sim.shm"

/* Offsets */
#define SIM_SECONDS_OFFSET      0
#define SIM_MICROSECONDS_OFFSET 4
#define SIM_GLOBAL_SYNC_FLAG_OFFSET 16

/* This set a MAX_THREAD upper limit to 64 */
#define SIM_PTHREAD_SLURMCTL_PID     8 
#define SIM_PTHREAD_SLURMD_PID      12

/* Pointer to shared memory initialized by sim_mgr */
void *timemgr_data;

/* Pointers to shared memory data */
unsigned int *current_sim;
unsigned int *current_micro;

/* Funtions */
static void _print_date( void );

int
main (int argc, char *argv[]) {
	_print_date ();
}

static void
_print_date() {
	time_t now = *current_sim;
	printf("%s", ctime( &now ));
}

int building_shared_memory() {
	int fd;

	fd = shm_open(SLURM_SIM_SHM, O_RDWR, S_IRUSR | S_IWUSR);
	if(fd < 0) {
		printf("Error opening %s\n", SLURM_SIM_SHM);
		return -1;
	}

	ftruncate(fd, 32);

	timemgr_data = mmap(0, 32, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

	if(!timemgr_data) {
		printf("mmaping %s file can not be done\n", SLURM_SIM_SHM);
		return -1;
	}

	/* Initializing pointers to shared memory */
	current_sim   = timemgr_data + SIM_SECONDS_OFFSET;
	current_micro = timemgr_data + SIM_MICROSECONDS_OFFSET;

	return 0;
}

void __attribute__ ((constructor)) simdate_init(void){
    if(building_shared_memory() < 0) {
        printf("Error building shared memory and mmaping it\n");
    };
}
