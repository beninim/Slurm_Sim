OUT=fare_build.log
ix=1

while [ -f ${OUT}.${ix} ]
do
	(( ix = ix + 1 ))
done

script -x
(
	install.pl
) 2>&1 | tee ${OUT}.${ix}
