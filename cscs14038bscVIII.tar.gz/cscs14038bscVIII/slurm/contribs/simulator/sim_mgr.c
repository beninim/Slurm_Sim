#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/tcp.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/syscall.h> /* SYS_gettid */
#include <pwd.h>
#include <ctype.h>
#include <sim_trace.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <config.h>
#include <slurm/slurm_errno.h>
#include <src/common/forward.h>
#include <src/common/hostlist.h>
#include <src/common/node_select.h>
#include <src/common/parse_time.h>
#include <src/common/slurm_accounting_storage.h>
#include <src/common/slurm_jobcomp.h>
#include <src/common/slurm_protocol_pack.h>
#include <src/common/switch.h>
#include <src/common/xassert.h>
#include <src/common/xstring.h>
#include <src/common/assoc_mgr.h>
#include <src/common/slurm_sim.h>
#include <getopt.h>

#undef DEBUG
int sim_mgr_debug_level = 9;

#define sim_mgr_debug(debug_level, ...) \
    ({ \
     if(debug_level >= sim_mgr_debug_level) \
     printf(__VA_ARGS__); \
     })

#define SAFE_PRINT(s) (s) ? s : "<NULL>"

char  daemon1[1024];
char  daemon2[1024];
char  default_sim_daemons_path[] = "/sbin";
char* sim_daemons_path = NULL;

char SEM_NAME[] = "serversem";
sem_t* mutexserver;

static pid_t pid[2] = {-1, -1};
static int launch_daemons = 0;
char** envs;

long int sim_start_point; /* simulation time starting point */
long int sim_end_point;   /* simulation end point is an optional parameter */

job_trace_t *trace_head, *trace_tail;
rsv_trace_t *rsv_trace_head, *rsv_trace_tail;

char*  global_envp[100];  /* Uhmmm ... I do not like this limitted number of env values */
time_t time_incr = 1;     /* Amount to increment the simulated time by on each pass */
int    signaled  = 0;     /* signal from slurmd */
char*  workload_trace_file = NULL; /* Name of the file containing the workload to simulate */
char   default_trace_file[] = "test.trace";
char   help_msg[]= "sim_mgr [endtime]\n\t[-c | --compath <cpath>]\n\t[-f | "
		   "--fork]\n\t[-a | --accelerator <secs>]\n\t[-w | --wrkldfile"
		   " <filename> ]\n\t[-h | --help]\nNotes:\n\t'endtime' is "
		   "specified as seconds since Unix epoch. If 0 is specified "
		   "then the\n\t\tsimulator will run indefinitely.\n\t'cpath' "
		   "is the path to the slurmctld and slurmd (applicable only if"
		   " launching\n\t\tdaemons).  Specification of this option "
		   "supersedes any setting of\n\t\tSIM_DAEMONS_PATH.  If "
		   "neither is specified then the sim_mgr looks in a\n\t\t"
		   "sibling directory of where it resides called sbin.  "
		   "Finally, if still\n\t\tnot found then the default is /sbin."
		   "\n\t'secs' for the accelerator switch is the interval, in "
		   "simulated seconds, to\n\t\tincrement the simulated time "
		   "after each cycle instead of merely one.\n\t'filename' is "
		   "the name of trace file containing the information of the "
		   "jobs to\n\t\tsimulate.";

/* Function prototypes */
void  generateJob(job_trace_t* jobd);
void  dumping_shared_mem();
void  fork_daemons(int idx);
char* getPathFromSelf(char*);
char* getPathFromEnvVar(char*);
int   getArgs(int, char**);
int   countEnvVars(char** envp);
uid_t userIdFromName(const char *name, gid_t* gid); /* function to get uid from username*/
#if 0
void  displayJobTraceT(job_trace_t* rptr);
#endif

/* handler to USR2 signal*/
void
handlerSignal(int signo) {
	signaled++;
	printf ("SIM_MGR [%d] got a %d signal--signaled: %d\n", getpid (), signo, signaled);
}


void
change_debug_level(int signum) {

	if(sim_mgr_debug_level > 0)
		sim_mgr_debug_level = 0;
	else
		sim_mgr_debug_level = 9;
}

void
terminate_simulation(int signum) {

	int i;

	dumping_shared_mem();

	sem_close(mutexserver);
	sem_unlink(SEM_NAME);

	slurm_shutdown(0); /* 0-shutdown all daemons without a core file */

	if(signum == SIGINT)
		exit(0);

	return;
}

/* Debugging */
void
dumping_shared_mem() {
	struct timeval t1;

	printf("Let's dump the shared memory contents\n");

	gettimeofday(&t1, NULL);
	printf("SIM_MGR[%u][%ld][%ld]\n", current_sim[0], t1.tv_sec, t1.tv_usec);

	return;
}

/* This is the main simulator function */
static void*
time_mgr(void *arg) {

	int child;
	long int wait_time;
	struct timeval t1 /*, t2*/;
	int i, j;

	printf("INFO: Creating time_mgr thread\n");

	current_sim      = timemgr_data + SIM_SECONDS_OFFSET;
	current_micro    = timemgr_data + SIM_MICROSECONDS_OFFSET;
	global_sync_flag = timemgr_data + SIM_GLOBAL_SYNC_FLAG_OFFSET;

	memset(timemgr_data, 0, 32); /* st on 14-October-2015 moved from build_shared_memory to here as only sim_mgr should change the values, even if someone else "built" the shm segment. */

	current_sim[0]   = sim_start_point;
	current_micro[0] = 0;

	/*signal (SIGUSR2, handlerSignal);*/
	printf("Waiting for signals, signaled: %d...\n", signaled);
	info("Waiting for signals..\n");
	while (signaled < 1 ){
		sleep(1); printf("... signaled: %d\n", signaled);
	}
printf("Done waiting.\n");
#ifdef DEBUG
	gettimeofday(&t1, NULL);
	printf("SIM_MGR[%u][%ld][%ld]\n", current_sim[0], t1.tv_sec, t1.tv_usec);
#endif


	/* Main simulation manager loop */
	while (1) {

		/* Do we have to end simulation in this cycle? */
		if (sim_end_point && sim_end_point <= current_sim[0]) {

			terminate_simulation(SIGINT);
		}

		/* First going through threads and leaving a chance to execute code */

		gettimeofday(&t1, NULL);

		sim_mgr_debug(3, "SIM_MGR[%u][%ld][%ld]\n",
				current_sim[0], t1.tv_sec, t1.tv_usec);

#if 1
		/* Now checking if a new reservation needs to be created */
		if(rsv_trace_head &&
			(current_sim[0] >= rsv_trace_head->creation_time) ) {

			int exec_result;

			printf("Creation reservation for %s [%u - %ld]\n",
				rsv_trace_head->rsv_command, current_sim[0],
				rsv_trace_head->creation_time);

			child = fork();

			if (child == 0) { /* the child */
				char* const rsv_command_args[] = {
						rsv_trace_head->rsv_command,
						NULL
				};

				if(execve(rsv_trace_head->rsv_command,
						rsv_command_args,
						global_envp) < 0) {
					printf("Error in execve for %s\n",
						rsv_trace_head->rsv_command);
					printf("Exiting...\n");
					exit(-1);
				}
			}

			waitpid(child, &exec_result, 0);
			if(exec_result == 0)
				sim_mgr_debug(9, "reservation created\n");
			else
				sim_mgr_debug(9, "reservation failed");

			rsv_trace_head = rsv_trace_head->next;
		}
#endif

		/* Now checking if a new job needs to be submitted */
		while(trace_head) {

			int hour,min,sec;
			int exec_result;
			static int failed_submissions = 0;

			/*
			 * Uhmm... This is necessary if a large number of jobs
			 * are submitted at the same time but it seems
			 * to have an impact on determinism
			 */

#ifdef DEBUG
			printf("time_mgr: current %u and next trace %ld\n",
					*(current_sim), trace_head->submit);
#endif

			if (*(current_sim) >= trace_head->submit) {

				job_trace_t *temp_ptr;

#ifdef DEBUG
				printf("[%d] time_mgr--current simulated time: "
				       "%u\n", __LINE__, *current_sim);
#endif

				generateJob (trace_head);

				/* Let's free trace record */
				temp_ptr = trace_head;
				trace_head = trace_head->next;
				free(temp_ptr);

			} else {
				/*
				 * The job trace list is ordered in time so
				 * there is nothing else to do.
				 */
				break;
			}
		}

		/* Synchronization with daemons */
		sem_wait(mutexserver);
		*global_sync_flag = 2;
		sem_post(mutexserver);
		while(*global_sync_flag > 1 && *global_sync_flag != '*') {
			usleep(100000);
		}
		/*
		 * Time throttling added but currently unstable; for now, run
		 * with only 1 second intervals
		 */

		*(current_sim) = *(current_sim) + time_incr;
#ifdef DEBUG
		printf("[%d] time_mgr--current simulated time: %lu\n",
					__LINE__, *current_sim);
#endif
	}

	return 0;
}

void
generateJob(job_trace_t* jobd) {
	job_desc_msg_t dmesg;
	submit_response_msg_t respMsg, *rptr = &respMsg;
	int rv, ix, jx;
	char script[8192], line[1024];
	uid_t uidt;
	gid_t gidt;

#if 0
	displayJobTraceT(jobd);
#endif
	/*
	 * First, send special Simulator message to the slurmd to inform it
	 * when the given job should terminate.
	 */
	sim_job_msg_t req;
	slurm_msg_t   req_msg;
	slurm_msg_t   resp_msg;
	slurm_addr_t  remote_addr;
	char* this_addr;

	slurm_msg_t_init(&req_msg);
	slurm_msg_t_init(&resp_msg);
	req.job_id       = jobd->job_id;
	req.duration     = jobd->duration;
	req_msg.msg_type = REQUEST_SIM_JOB;
	req_msg.data     = &req;
	req_msg.protocol_version = SLURM_PROTOCOL_VERSION;
	this_addr = "localhost";
	slurm_set_addr(&req_msg.address, (uint16_t)slurm_get_slurmd_port(),
						this_addr);

	if (slurm_send_recv_node_msg(&req_msg, &resp_msg, 500000) < 0) {
		printf("check_events_trace: error in slurm_send_recv_node_msg\n");
	}

	sprintf(script,"#!/bin/bash\n");

	slurm_init_job_desc_msg(&dmesg);

	/* Second, set up and call Slurm C-API for actual job submission. */
	dmesg.time_limit    = jobd->wclimit;
	dmesg.job_id        = jobd->job_id;
	dmesg.name	    = "sim_job";
	uidt = userIdFromName(jobd->username, &gidt);
	dmesg.user_id       = uidt;
	dmesg.group_id      = gidt;
	dmesg.work_dir      = strdup("/tmp"); /* hardcoded to /tmp for now */
	dmesg.qos           = strdup(jobd->qosname);
	dmesg.partition     = strdup(jobd->partition);
	dmesg.account       = strdup(jobd->account);
	dmesg.reservation   = strdup(jobd->reservation);
	dmesg.dependency    = strdup(jobd->dependency);
	dmesg.num_tasks     = jobd->tasks;
	dmesg.min_cpus      = jobd->tasks;
	dmesg.cpus_per_task = jobd->cpus_per_task;
	dmesg.ntasks_per_node = jobd->tasks_per_node;

	/* Need something for environment--Should make this een more generic! */
	dmesg.environment  = (char**)malloc(sizeof(char*)*2);
	dmesg.environment[0] = strdup("HOME=/root");
	dmesg.env_size = 1;

	/* Standard dummy script. */
	sprintf(line,"#SBATCH -n %u\n", jobd->tasks);
	strcat(script, line);
	strcat(script, "\necho \"Generated BATCH Job\"\necho \"La Fine!\"\n");

	dmesg.script        = strdup(script);

	if ( slurm_submit_batch_job(&dmesg, &rptr) ) {
		printf("Function: %s, Line: %d\n", __FUNCTION__, __LINE__);
		slurm_perror ("slurm_submit_batch_job");
	}

	printf("\nResponse from job submission\n\terror_code: %u\n\t"
	       "job_id: %u\n\tstep_id: %u\n",
		respMsg.error_code, respMsg.job_id, respMsg.step_id);
	printf("\n");
	/* Should release the memory of the dmesg. */
}

uid_t
userIdFromName(const char *name, gid_t* gid) {
	struct passwd *pwd;
	uid_t u;
	char *endptr;

	*gid = -1;			    /* In case of error, a -1     */
					    /* would be returned.         */

	if (name == NULL || *name == '\0')  /* On NULL or empty string    */
		return -1;                  /* return an error            */

	u = strtol(name, &endptr, 10);      /* As a convenience to caller */
	if (*endptr == '\0') {              /* allow a numeric string     */
		pwd = getpwuid(u);
		if (pwd == NULL)
			printf("Warning!  Could not find the group id "
			       "corresponding to the user id: %u\n", u);
		else
			*gid = pwd->pw_gid;
		return u;
	}

	pwd = getpwnam(name);
	if (pwd == NULL)
		return -1;

	*gid = pwd->pw_gid;

	return pwd->pw_uid;
}


int
insert_trace_record(job_trace_t *new) {

	if(trace_head == NULL){
		trace_head = new;
		trace_tail = new;
	} else {
		trace_tail->next = new;
		trace_tail = new;
	}
	return 0;
}

int
insert_rsv_trace_record(rsv_trace_t *new) {

	if(rsv_trace_head == NULL){
		rsv_trace_head = new;
		rsv_trace_tail = new;
	} else {
		rsv_trace_tail->next = new;
		rsv_trace_tail = new;
	}
	return 0;
}

int
init_trace_info(void *ptr, int op) {

	job_trace_t *new_trace_record;
	rsv_trace_t *new_rsv_trace_record;
	static int count = 0;

	if (op == 0) {
		new_trace_record = calloc(1, sizeof(job_trace_t));
		if (new_trace_record == NULL) {
			printf("init_trace_info: Error in calloc.\n");
			return -1;
		}

		*new_trace_record = *(job_trace_t *)ptr;

		if (count == 0) {
			sim_start_point = new_trace_record->submit - 60;
			/*first_submit = new_trace_record->submit;*/
		}

		count++;

		insert_trace_record(new_trace_record);
	}

	if (op == 1) {
		new_rsv_trace_record = calloc(1, sizeof(rsv_trace_t));
		if (new_rsv_trace_record == NULL) {
			printf("init_trace_info: Error in calloc for"
			       " new reservation\n");
			return -1;
		}

		*new_rsv_trace_record = *(rsv_trace_t *)ptr;
		new_rsv_trace_record->next = NULL;

		printf("Inserting new reservation trace record for time %ld\n",
		new_rsv_trace_record->creation_time);

		insert_rsv_trace_record(new_rsv_trace_record);
	}

	return 0;
}

#if 0
void displayJobTraceT(job_trace_t* rptr) {
	printf(
		"%8d"
		" %10s"
		" %12ld"
		" %10d"
		" %10d"
		" %7d"
		" %12s"
		" %12s"
		" %12s"
		" %15d"
		" %17d"
		" %12s"
		" %12s"
		"\n",
		rptr->job_id,
		SAFE_PRINT(rptr->username),
		rptr->submit,
		rptr->duration,
		rptr->wclimit,
		rptr->tasks,
		SAFE_PRINT(rptr->qosname),
		SAFE_PRINT(rptr->partition),
		SAFE_PRINT(rptr->account),
		rptr->cpus_per_task,
		rptr->tasks_per_node,
		SAFE_PRINT(rptr->reservation),
		SAFE_PRINT(rptr->dependency)
);
}
#endif

int init_job_trace() {
	int trace_file;
	job_trace_t new_job;
	int total_trace_records = 0;

	trace_file = open(workload_trace_file, O_RDONLY);
	if (trace_file < 0) {
		printf("Error opening file %s\n", workload_trace_file);
		return -1;
	}

#if 0
	printf("%8s %10s %12s %10s %10s %7s %12s %12s %12s %15s %17s %12s %12s\n",
		"job_id:", "username:", "submit:", "duration:", "wclimit:",
		"tasks:", "qosname:", "partition: ", "account:", "cpus_per_task:",
		"tasks_per_node:", "reservation:", "dependency: ");
#endif
	while(read(trace_file, &new_job, sizeof(new_job))) {
#if 0
		displayJobTraceT(&new_job);
#endif
		init_trace_info(&new_job, 0);
		total_trace_records++;
	}

	printf("Trace initialization done. Total trace records: %d\n",
					total_trace_records);

	close(trace_file);

	return 0;
}

int init_rsv_trace() {

	int trace_file;
	rsv_trace_t new_rsv;
	int total_trace_records = 0;
	int count;
	char new_char;
	char buff[20];

	trace_file = open("rsv.trace", O_RDONLY);
	if(trace_file < 0){
		/*printf("Error opening file rsv.trace\n");*/
		printf("Warning!  Can NOT open file rsv.trace\n");
		return -1;
	}

	new_rsv.rsv_command = malloc(100);
	if(new_rsv.rsv_command < 0){
		printf("Malloc problem with reservation creation\n");
		return -1;
	}

	memset(buff, '\0', 20);
	memset(new_rsv.rsv_command, '\0', 100);

	while(1) {

		count = 0;

		/* First reading the creation time value */
		while(read(trace_file, &new_char, sizeof(char))) {

			if(new_char == '=')
				break;

			buff[count++] = new_char;
		}

		if(count == 0)
			break;

		new_rsv.creation_time = (long int)atoi(buff);

		count = 0;

		/* then reading the script name to execute */
		while(read(trace_file, &new_char, sizeof(char))) {

			new_rsv.rsv_command[count++] = new_char;

			if(new_char == '\n') { 
				new_rsv.rsv_command[--count] = '\0';
				break;
			}
		}

#if DEBUG
printf("Reading filename %s for execution at %ld\n",
		new_rsv.rsv_command, new_rsv.creation_time);
#endif

		init_trace_info(&new_rsv, 1);
		total_trace_records++;
		if(total_trace_records > 10)
			break;
	}


	printf("Trace initializarion done. Total trace records for "
			   "reservations: %d\n", total_trace_records);

	close(trace_file);

	return 0;
}

int
open_global_sync_semaphore() {
	mutexserver = sem_open(SEM_NAME, O_CREAT, 0644, 1);
	if(mutexserver == SEM_FAILED) {
		perror("unable to create server semaphore");
		sem_unlink(SEM_NAME);
		return -1;
	}

	return 0;
}


int
main(int argc, char *argv[], char *envp[]) {

	pthread_attr_t attr, attr2;
	pthread_t id_mgr/*, id_launch*/;   
	int i, status_ctld, status_slud;
	char thelib[1024];
	struct stat buf;
	int ix, envcount = countEnvVars(envp);

	signal (SIGUSR2, handlerSignal);

	if ( !getArgs(argc, argv) ) {
		printf("Usage: %s\n", help_msg);
		exit(-1);
	}

	/* Determine location of the simulator library and Slurm daemons */

	if (!sim_daemons_path) {
		sim_daemons_path = getPathFromEnvVar("SIM_DAEMONS_PATH");}
	if (!sim_daemons_path)  {sim_daemons_path = getPathFromSelf("sbin");}

	if (!sim_daemons_path) {
		sim_daemons_path = default_sim_daemons_path;
	}

	/*sprintf(env_var1, "LD_LIBRARY_PATH=%s", sim_library_path);*/
	sprintf(daemon1,"%s/slurmctld", sim_daemons_path);
	sprintf(daemon2,"%s/slurmd",    sim_daemons_path);

	if ( stat(daemon1, &buf) == -1 ) {
		printf("Error!  Can not stat the slurmctld command: (%s).\n"
		       "Aborting the sim_mgr.\n", daemon1);
		exit(-1);
	}
	if ( stat(daemon2, &buf) == -1 ) {
		printf("Error!  Can not stat the slurmd command: (%s).\n"
		       "Aborting the sim_mgr.\n", daemon2);
		exit(-1);
	}

	printf("Settings:\n--------\n");
	printf("launch_daemons: %d\nsim_daemons_path: %s\n"
		"sim_end_point: %ld\nslurmctld: %s\nslurmd: %s\nenvironment "
		"\n\n\n",
		launch_daemons, SAFE_PRINT(sim_daemons_path), sim_end_point, daemon1, daemon2);

	/* Set up global environment list for later use in forking the daemons. */
	envs = (char**)malloc(sizeof(char*)*(envcount+1));
	for(ix=0; ix<envcount; ix++) envs[ix] = envp[ix];
	envs[ix]   = NULL;

	i = 0;
	while(envp[i]){
		global_envp[i] = envp[i++];
	}
	global_envp[i] = NULL;


	if(open_global_sync_semaphore() < 0){
		printf("Error opening the global synchronization semaphore.\n");
		return -1;
	};

	/* Launch the slurmctld and slurmd here */
	if (launch_daemons) {
		if(pid[0] == -1) fork_daemons(0);
		if(pid[1] == -1) fork_daemons(1);
		waitpid(pid[0], &status_ctld, 0);
		waitpid(pid[1], &status_slud, 0);
	}

	if(init_job_trace() < 0){
		printf("An error was detected when reading trace file. "
		       "Exiting...\n");
		return -1;
	}

	if(init_rsv_trace() < 0){
		printf("An error was detected when reading trace file. \n"
		       /*"Exiting...\n"*/);
		/*return -1;*/
	}

	pthread_attr_init(&attr);
	signal(SIGINT, terminate_simulation);
	signal(SIGHUP, terminate_simulation);
	signal(SIGUSR1, change_debug_level);

	pthread_attr_init(&attr);

	/* This is a thread for flexibility */
	while (pthread_create(&id_mgr, &attr, &time_mgr, 0)) {
		printf("Error with pthread_create for time_mgr\n"); 
		return -1;
	}

	pthread_join(id_mgr, NULL);
	sleep(1);

	/*free(sim_library_path);*/
	return 0;
}

int
countEnvVars(char** envp) {
	int rv = 0;
	while(envp[rv]) ++rv;
	return rv;
}

void
fork_daemons(int idx) {
	char* args[3];

#if DEBUG
	printf("PROCESS: %d THREAD: %d FILE: %s FUNCTION: %s LINE: %d--about to"
	       " fork with idx: %d mutex_lock\n", getpid(), syscall(SYS_gettid),
		__FILE__, __FUNCTION__, __LINE__, idx);
#endif
	if(pid[idx]==-1) {
		pid[idx] = fork();
		if(pid[idx]==0) {
			if (idx==0) {
				args[0] = daemon1;
				args[1] = "-c";
				args[2] = NULL;
				execvpe(daemon1, args, envs);
			} else {
				args[0] = daemon2;
				args[1] = NULL;
				execvpe(daemon2, args, envs);
			}
			printf("Reached here--something went wrong!\n");
		}
	}
}

/*
 * Tries to find a path based on the location of the sim_mgr executable.
 * If found, appends the "subpath" argument to it.
 */
char*
getPathFromSelf(char* subpath) {
	char* path,* ptr,* newpath = NULL;

	path = getenv("_");
	if (path) {
		newpath = strdup(path);
		ptr = strrchr(newpath, '/');
		if (ptr) {
			*ptr = '\0';
			ptr = strrchr(newpath, '/');
			if (ptr) {
				*ptr = '\0';
			} else {
				sprintf(newpath,"..");
			}
			strcat(newpath,"/");
			strcat(newpath, subpath);
		}
	}

	return newpath;
}

char*
getPathFromEnvVar(char* env_var) {
	char* path, *newpath = NULL;

	path = getenv(env_var);
	if(path) newpath = strdup(path);

	return newpath;
}

/*
 * Returns 1 if input is valid
 *         0 if input is not valid
 */
int
getArgs(int argc, char** argv) {
	static struct option long_options[]  = {
		{"fork",	0, 0, 'f'},
		{"compath",	1, 0, 'c'},
		{"accelerator",	1, 0, 'a'},
		{"wrkldfile",	1, 0, 'w'},
		{"help",	0, 0, 'h'}
	};
	int ix = 0, valid = 1;
	int opt_char, option_index;
	char* ptr;

	while (1) {
		if ((opt_char = getopt_long(argc, argv, "fc:ha:w:" , long_options,
						&option_index)) == -1 )
			break;

		switch(opt_char) {
			case ('f'):
				launch_daemons = 1;
				break;
			case ('c'):
				sim_daemons_path = strdup(optarg);
				break;
			case ('a'): /* Eventually use strtol instead of atoi */
				time_incr = atoi(optarg);
				break;
			case ('w'):
				workload_trace_file = strdup(optarg);
				break;
			case ('h'):
				printf("%s\n", help_msg);
				exit(0);
		};
	}

	if (optind < argc)
		for(ix = optind; ix<argc; ix++) {
			sim_end_point = strtol(argv[ix], &ptr, 10);

			/* If the argument is an empty string or ptr does not
			 * point to a Null character then the input is not
			 * valid.
			 */
			if ( !(argv[ix][0] != '\0' && *ptr == '\0') ) valid = 0;
		}

	if (!workload_trace_file) workload_trace_file = default_trace_file;

	return valid;
}
