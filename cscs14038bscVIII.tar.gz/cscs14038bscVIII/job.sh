#!/bin/ksh
#SBATCH -N 5000
#SBATCH --time=02:22:00

echo "Ciao mondo!"
sleep 22
echo "Ho finito!"
