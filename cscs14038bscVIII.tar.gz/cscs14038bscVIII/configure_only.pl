#!/usr/bin/perl

$SIMDIR=`pwd`;

chomp($SIMDIR);

$install_dir=$SIMDIR;

$config_command = "cd slurm;./configure
			--exec-prefix=$install_dir/slurm_programs
			 --bindir=$install_dir/slurm_programs/bin
			 --sbindir=$install_dir/slurm_programs/sbin
			 --datadir=$install_dir/slurm_varios/share
			 --includedir=$install_dir/slurm_varios/include
			 --libdir=$install_dir/slurm_varios/lib
			 --libexecdir=$install_dir/slurm_varios/libexec
			 --localstatedir=$install_dir/slurm_varios
			 --sharedstatedir=$install_dir/slurm_varios
			 --mandir=$install_dir/slurm_varios/man
			 --infodir=$install_dir/slurm_varios/share/info
			 --prefix=$install_dir/slurm_programs
			 --sysconfdir=$install_dir/slurm_conf
			 --localstatedir=$install_dir/slurm_varios/var/
			 --enable-pam
			 --with-proctrack
			 --with-ssl=$install_dir/slurm_varios/lib/slurm
			 --with-munge=/opt/munge/default
			 --enable-front-end
			 --with-mysql-config=/usr/bin/
			 --enable-simulator 2> slurm_configure.log";

print "Executing:\n $config_command\n";
system($config_command);
