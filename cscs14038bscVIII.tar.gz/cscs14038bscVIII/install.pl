#!/usr/bin/perl

$SIMDIR=`pwd`;

chomp($SIMDIR);

$install_dir=$SIMDIR;

$config_command = "cd slurm;./configure --exec-prefix=$install_dir/slurm_programs --bindir=$install_dir/slurm_programs/bin --sbindir=$install_dir/slurm_programs/sbin --datadir=$install_dir/slurm_varios/share --includedir=$install_dir/slurm_varios/include --libdir=$install_dir/slurm_varios/lib --libexecdir=$install_dir/slurm_varios/libexec --localstatedir=$install_dir/slurm_varios --sharedstatedir=$install_dir/slurm_varios --mandir=$install_dir/slurm_varios/man --infodir=$install_dir/slurm_varios/share/info --prefix=$install_dir/slurm_programs --sysconfdir=$install_dir/slurm_conf --localstatedir=$install_dir/slurm_varios/var/ --enable-pam --with-proctrack --with-ssl=$install_dir/slurm_varios/lib/slurm --with-munge=/opt/munge/default --enable-front-end --with-mysql-config=/usr/bin/ --enable-simulator 2> slurm_configure.log";

print "Executing:\n $config_command\n";
system($config_command);

print "\nNow compiling ... (It will take some minutes)\n";
system("cd slurm;make 2> make.log");
print ("... and installing ...\n");
system("cd slurm;make install 2> make-install.log");


# Let's check compilation and installation was successful
print ("Let's check compilation and installation was successful...\n");

if(-e "slurm_programs/sbin/slurmctld"){
    print "I got a slurmctld binary!\n";
}
else{
    die("Something was wrong during slurm building\n");
}

print ("It seems fine.\n");


# After slurm has been compiled and installed, let's take the sim_mgr program here

print "\There are some parameters at slurm_conf/slurm.con to adjust before slurm can run:\n";
print "\n\t\tSlurmUser\n";
print "\n\t\tSlurmdUser\n";
print "\n\t\tControlMachine\n";
print "\n\t\tControlAddr\n";
print "\n\t\tClusterName\n";
print "\n\t\tFrontendName\n";

print "\n\t Also check slurm_conf/slurm.nodes and set NodeHostName and NodeAddr if they are wrong\n";
print "\n\nDO NOT FORGET IT!\n\n";

print "\There are some parameters at slurm_conf/ to adjust before slurmdbd can run::\n";
print "\n\t\tStorageUser\n";
print "\n\t\tStoragePass\n";
print "\n\t\tSlurmUser\n";
print "\n\nDO NOT FORGET IT!\n\n";
